// Microblocks always require special handling.
if (FML.isModLoaded("ExtraUtilities")){
    NEI.override_block("ExtraUtilities", "drum", [0, 1]);

    if (FML.isModLoaded("ForgeMicroblock")){

        // Special handler for cleanly removing them.
        ExtraUtilities.obliterate_microblocks([1, 2, 3], ForgeMicroblock.getRandomMaterial());
    }
}