var vanilla_enabled = true;
var ThermalExpansion_enabled = true;
var Mekanism_enabled = true;
var ForgeMicroblock_enabled = true;
var ExtraUtilities_enabled = true;
var BuildCraft_enabled = true;
var Bibliocraft_enabled = true;
var AE2_enabled = true;