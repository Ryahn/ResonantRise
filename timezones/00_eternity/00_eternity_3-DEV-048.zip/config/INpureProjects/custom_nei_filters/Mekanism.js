if (FML.isModLoaded("Mekanism")){
    NEI.override_block("Mekanism", "GasTank", [100]);
}