if (FML.isModLoaded("gendustry") && Gendustry_enabled){
    NEI.hide("gendustry:GeneSample");
}
