if (FML.isModLoaded("pressure") && PressurePipes_enabled){
    NEI.override("pressure:Canister", [0]);
}
