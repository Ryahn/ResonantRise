if (FML.isModLoaded("extracells") && ExtraCells_enabled){
    NEI.override("extracells:pattern.fluid", [0]);
}
