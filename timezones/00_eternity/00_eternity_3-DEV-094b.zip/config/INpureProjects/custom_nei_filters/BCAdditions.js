if (FML.isModLoaded("bcadditions") && BCAdditions_enabled){
    NEI.override("bcadditions:ironCanister", [0]);
    NEI.override("bcadditions:goldCanister", [0]);
    NEI.override("bcadditions:diamondCanister", [0]);
}
